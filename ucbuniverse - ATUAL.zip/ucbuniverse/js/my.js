
function btnShow() {
    $('#botaoDownload').hide();
    setTimeout(function() {
        $('#botaoDownload').show();
    }, 1 * 60 * 1000);
};
