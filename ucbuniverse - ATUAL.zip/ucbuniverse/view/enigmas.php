<?php session_start();
if(!isset($_SESSION['matricula'])){
    header('Location: ../index.php');
}

$matricula = $_SESSION['matricula'];
require_once  '../class/controller/questoesController.php';

$quest = new QuestoesController();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>UCB UNIVERSE</title>

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Press+Start+2P&display=swap" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="background">
    <div class="font-main">
        <div class="text-center">
            <!--<h1 class="mt-6">UCB <p>UNIVERSE</p></h1>-->
            <div class="mt-3">
                <img src="../pix/title.png" alt="some text" width="400" height="100">
            </div>
            <div class="title-sub, mt-5">
                <h2>ENIGMAS</h2>
            </div>
            <div class="row justify-content-md-center">
                <div class="col-6">
                    <form action="#" id="form" class="card-header form-group" method="POST" role="form" target="_self">
                    <?php

                    $array = $quest->buscaQuest();
                    $i=0;
                    foreach ($array as $key => $value) {

                        $id = $value->id;
                        $titulo = $value->titulo;
                        $enunciado = $value->enunciado;
                        $resposta = $value->resposta;
                        $capitulo = $value->capitulo;
                        $pontuacao = $value->pontuacao;

                        ?>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active" aria-current="page"><a
                                            href="abreEnigma.php"><?php echo $titulo; ?></a></li>
                            </ol>
                        </nav>
                        <?php

                    }
                    ?>
                    </form>
                </div>
            </div>
        </div>


    </div>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="../js/bootstrap.min.js"></script>
</body>
</html>