<html>
<head>
    <script type="text/javascript" src="../js/qrcode.js"></script>
</head>
<body>
<input type="text" id="valor" value="">
<button onClick="createQrCode()">Gerar QR Code</button>
<div id="qrcode"></div>
</body>
<script>

    function createQrCode()
    {
        var userInput = document.getElementById('valor').value;
        var qrcode = new QRCode("qrcode", {
            text: userInput,
            width: 256,
            height: 256,
            colorDark: "black",
            colorLight: "white",
            correctLevel : QRCode.CorrectLevel.H
        });
    }

</script>
</html>